/*
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Interactable1 : MonoBehaviour
{
    private Outline outline; // Reference to the Outline component

    void Awake()
    {
        outline = GetComponent<Outline>(); // Get Outline component
        if (outline != null)
        {
            outline.enabled = false; // Start with outline disabled
        }
    }

    public virtual void BaseInteract()
    {
        Debug.Log("Interacted with " + gameObject.name);
    }

    public void EnableOutline()
    {
        if (outline != null)
        {
            outline.enabled = true;
        }
    }

    public void DisableOutline()
    {
        if (outline != null)
        {
            outline.enabled = false;
        }
    }
}
*/
