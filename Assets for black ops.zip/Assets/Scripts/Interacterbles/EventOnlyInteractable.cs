using UnityEngine;

public class EventOnlyInteractable : Interactable   
{
   
}
